<?php

$get_each_cords_points = $_GET['input'];
//$get_each_cords_points1 = $_GET['input1'];

echo file_get_contents($get_each_cords_points);
//echo file_get_contents($get_each_cords_points1);
echo "<br>";
//echo "<input type=\"button\" name=\"blocksANDlines\" id=\"blocksANDlines\" value=\"Change\">";
?>
