<?php

$get_each_cords_points = $_GET['input'];

echo file_get_contents($get_each_cords_points);

?>
