<div id="smallLogoDiv">
<img src="img/GSV_Web_Small.png">
</div>
<div id="header_homepage">
        <ul id="nav">
        <li></li>
        <li><a href=<?php echo $webpath;?>homepage.php>Home</a></li>
        <li><a href=<?php echo $webpath;?>about.php>About</a></li>
        <li><a href=<?php echo $webpath;?>tutorial.php>Tutorial</a></li>
        <li><a href=<?php echo $webpath;?>faq.php>FAQ</a></li>
        <li><a href=<?php echo $webpath;?>software.php>Download</a></li>
        <li><a href=<?php echo $webpath;?>support.php>Contact</a></li>
	</ul>
</div>
