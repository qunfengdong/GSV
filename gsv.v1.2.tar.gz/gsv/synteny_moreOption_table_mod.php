<div id="body">
<p class="bodypara">
<table class="bodypara" width="100%">
 <tr>
<td><span style="color:662d91"><b>Select Reference and Query Genomes:</b></span>
  &nbsp;&nbsp;<?php select_org(); ?></td>
</tr>
  </table>
