<div id="footer">
<a href="http://www.indiana.edu">

</a>
<a href= "http://copyright.unt.edu/content/unt-copyright-resources" title="Copyright">Copyright</a>
&copy;&nbsp;UNT
</div>
