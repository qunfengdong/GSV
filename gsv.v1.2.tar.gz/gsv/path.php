<?php

#########link webpage to one another###############
$webpath = "";
###################################################
########store uploaded files location####################
$uploadpath = $_SERVER['DOCUMENT_ROOT']."/gsv/syn/"; 

###################################################
######For display.php and list.php#################
$webpath_home = "homepage.php";
$webpath_about = "about.php";
$webpath_faq = "faq.php";
$webpath_software = "software.php";
$webpath_support = "support.php";
$webpath_tutorial = "tutorial.php";
###################################################
?>
